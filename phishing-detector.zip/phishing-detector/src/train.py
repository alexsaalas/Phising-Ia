from detector.model import PhishingDetector

detector = PhishingDetector()
detector.train_model()